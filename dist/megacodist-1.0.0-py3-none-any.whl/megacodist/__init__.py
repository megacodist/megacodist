"""This package contains some useful APIs to extend Python Standard
Library.
"""