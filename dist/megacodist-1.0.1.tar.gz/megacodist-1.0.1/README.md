# megacodist
 A Python library for regular and repeatitive tasks.
